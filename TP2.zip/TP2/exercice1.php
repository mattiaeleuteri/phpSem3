<?php

foreach ($_SERVER as $cle=>$valeur){
    echo "$cle : $valeur <br/>";
}